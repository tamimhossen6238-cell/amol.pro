const CACHE_NAME = 'amol-v6';
const ASSETS_TO_CACHE = [
  './',
  './index.html',
  './manifest.json',

  // App Scripts - CRITICAL for offline functionality
  './index.js',
  './App.js',
  './types.js',
  './constants.js',
  './components/Dashboard.js',
  './components/TasbihList.js',
  './components/FocusMode.js',
  './components/TargetList.js',
  './components/Journal.js',
  './components/Garden.js',
  './components/Analysis.js',
  './components/Inbox.js',
  './components/BottomNav.js',

  // App Assets
  'https://i.ibb.co/3fdBf81/islamic-moon.png',

  // External Libraries & Fonts
  'https://cdn.tailwindcss.com',
  'https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap',
  'https://esm.sh/react@^19.2.3',
  'https://esm.sh/react-dom@^19.2.3/client',
  'https://esm.sh/lucide-react@^0.562.0',
  'https://esm.sh/recharts@^3.6.0',
  'https://esm.sh/react-hot-toast@^2.6.0',
  'https://esm.sh/canvas-confetti@^1.9.4'
];

// Install Event - Cache Files
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('Opened cache and caching assets');
      return cache.addAll(ASSETS_TO_CACHE);
    }).catch(err => {
      console.error('Failed to cache assets during install:', err);
    })
  );
  self.skipWaiting();
});

// Activate Event - Clean old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            console.log('Deleting old cache:', cache);
            return caches.delete(cache);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch Event - More robust cache-first strategy
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      // Return the cached response if it's found.
      if (cachedResponse) {
        return cachedResponse;
      }

      // If not in cache, fetch from the network.
      return fetch(event.request).then((networkResponse) => {
        // Only cache valid, successful responses for JS/CSS/Fonts from CDNs
        if (networkResponse && networkResponse.status === 200) {
           const url = new URL(event.request.url);
           if (url.hostname === 'esm.sh' || url.hostname === 'fonts.gstatic.com') {
              const responseToCache = networkResponse.clone();
              caches.open(CACHE_NAME).then((cache) => {
                cache.put(event.request, responseToCache);
              });
           }
        }
        return networkResponse;
      }).catch(() => {
         // If the network fails for a navigation request, serve the main HTML page.
         if (event.request.mode === 'navigate') {
           return caches.match('./index.html');
         }
         // For other failed requests, do nothing to avoid errors.
      });
    })
  );
});

// Notification Click Event
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // If a window is already open, focus it.
      for (const client of clientList) {
        if (client.url === self.registration.scope && 'focus' in client) {
          return client.focus();
        }
      }
      // Otherwise, open a new window.
      if (clients.openWindow) {
        return clients.openWindow('./index.html');
      }
    })
  );
});